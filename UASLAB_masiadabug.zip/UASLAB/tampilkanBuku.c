#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"

void showBukuTersedia() {
    Buku buku[MAX_BOOKS];
    int jumlah_buku;
    jumlah_buku = hitung_jumlah_buku(buku);
    FILE *file = fopen("databuku.txt", "r+");
    if (file == NULL) {
        printf("Gagal membuka file databuku.txt\n");
        exit(EXIT_FAILURE);
    }
    printf("Buku yang tersedia:\n");
    for (int i = 0; i < jumlah_buku; i++) {
        printf("\n-- BUKU--\n");
        printf("ID buku: %u", buku[i].id);
        printf("\nJudul:%s", buku[i].judul);
        printf("\nPenulis: %s", buku[i].penulis);
        printf("\nPenerbit: %s", buku[i].penerbit);
        printf("\nJumlah halaman: %u", buku[i].jumlah_halaman);
        printf("\nTahun terbit: %u", buku[i].tahun_terbit);
        printf("\nJumlah buku tersedia: %u", buku[i].jumlah_buku_tersedia);
    }
    fclose(file);
}

int hitung_jumlah_buku(Buku *daftar_buku) {
    FILE *file = fopen ("databuku.txt","r");
    if (file == NULL){
        printf("Error opening file!");
        exit (EXIT_FAILURE);
    }

    int jumlah_buku = 0;
    Buku temp;

    while (fscanf(file, "%u \"%99[^\"]\" \"%99[^\"]\" \"%99[^\"]\" %u %u %u\n", 
                  &temp.id, 
                  temp.judul, 
                  temp.penulis, 
                  temp.penerbit, 
                  &temp.jumlah_halaman, 
                  &temp.tahun_terbit, 
                  &temp.jumlah_buku_tersedia) != EOF) {
        jumlah_buku++;
    }

    fclose(file);
    return jumlah_buku;
}




// Fungsi untuk menampilkan daftar peminjaman buku
void showlistPeminjaman() {
    FILE *file = fopen("listpeminjaman.txt", "r");
    if (file == NULL) {
        printf("Belum ada buku yang dipinjam.\n");
        return;
    }

    printf("\nDaftar Buku yang Dipinjam:\n");
    printf("ID User\tID Buku\tJudul Buku\n");
    printf("----------------------------------------------------------------\n");

    BukuDipinjam buku_dipinjam;
    while (fscanf(file, "%d,%u,%99[^\n]", &buku_dipinjam.id_user, &buku_dipinjam.id_buku, buku_dipinjam.judul) == 3) {
        printf("ID User: %d\n", buku_dipinjam.id_user);
        printf("ID Buku: %u\n", buku_dipinjam.id_buku);
        printf("Judul Buku: %s\n", buku_dipinjam.judul);
        printf("================================================================\n");
    }

    fclose(file);
}